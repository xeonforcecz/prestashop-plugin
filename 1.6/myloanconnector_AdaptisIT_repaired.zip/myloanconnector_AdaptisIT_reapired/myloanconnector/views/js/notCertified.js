$(document).ready(function () {

    $('#hc-select-payment').click(function () {
        window.location.href = actionUrl;
    });
});